# NavigationDrawer-WaveAnimation
The idea is to create wave transitions below the header when the user opens the Navigation Drawer,
the transitions have to be meaningful so I created a loop of 5 different waves 
that synched with each other in a series order using Android's VectorDrawable.

![Alt Text](https://cdn-images-1.medium.com/max/1600/1*-QxingaedQq6R5ArUKwNvw.gif)

Full Documentation here 

https://medium.com/@youssefassad/navigation-drawer-with-wave-animation-21bfb4e647fd



```
MIT License

Copyright (c) 2018 Youssef Assad

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so.
```
